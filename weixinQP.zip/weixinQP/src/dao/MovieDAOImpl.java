package dao;
import java.sql.*;
import java.util.*;

import movie.Movie;
public class MovieDAOImpl implements MovieDAO {
	private String dbClassName="com.mysql.jdbc.Driver";
	private String dbUrl="jdbc:mysql://localhost:3306/movie?characterEncoding=utf8";
	private String dbUser="root";
	private String dbPwd="1234";
	
	public MovieDAOImpl(){
	}
	//��ȡConnection����
	public Connection getConnection(){
		Connection conn = null;
		try{
			Class.forName(dbClassName);
			conn=DriverManager.getConnection(dbUrl, dbUser, dbPwd);
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return conn;
	}
	//�����Ӱ
	public void saveMovie(Movie movie){
		Connection con = null;
		PreparedStatement stmt = null;
		try{
			con=getConnection();
			con.setAutoCommit(false);
			stmt=con.prepareStatement("insert into myorder(id,name,cinema,seat,time,price)values(?,?,?,?,?,?)");
			stmt.setInt(1,movie.getId());
			stmt.setString(2,movie.getName());
			stmt.setString(3,movie.getCinema());
			stmt.setString(4,movie.getSeat());
			stmt.setString(5,movie.getTime());
			stmt.setInt(6,movie.getPrice());
			stmt.execute();
			con.commit();
		}catch(Exception e){
			try{
				con.rollback();
			}catch(SQLException sqlex){
				sqlex.printStackTrace();
			}
		}finally{
			try{
				stmt.close();
				con.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
	//�������е�Ӱ
	public  ArrayList<Movie> listAllMovie(){
		ArrayList<Movie> list = new ArrayList<Movie>();
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try{
			con = getConnection();
			stmt = con.prepareStatement("select * from movie_information");
			rs = stmt.executeQuery();
			while(rs.next()){
				Movie movie = new Movie();
				movie.setName(rs.getString(1));
				movie.setCinema(rs.getString(2));
				//movie.setSeat(rs.getString());
				movie.setTime(rs.getString(3));
				movie.setPrice(rs.getInt(4));
				list.add(movie);
			}
			rs.close();
			stmt.close();
			con.close();
		}catch(SQLException sqlex){
			sqlex.printStackTrace();
		}
		return list;
	}
	//ͨ��id����
	public Movie listMovieById(int id){
		Movie movie = new Movie();
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try{
			con = getConnection();
			//stmt = con.createStatement(sql);
			rs = stmt.executeQuery();
			if(rs.next()){
				movie.setId(rs.getInt(1));
				movie.setName(rs.getString(2));
				movie.setCinema(rs.getString(3));
				movie.setSeat(rs.getString(4));
				movie.setTime(rs.getString(5));
				movie.setPrice(rs.getInt(6));
			}
			rs.close();
			stmt.close();
			con.close();
		}catch(SQLException sqlex){
			sqlex.printStackTrace();
		}
		return movie;
	}
	public void saveMOvie(Movie movie) {
		// TODO Auto-generated method stub
		
	}
			
}

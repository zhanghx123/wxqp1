package dao;

import java.util.ArrayList;

import movie.Movie;

public interface MovieDAO {
	public void saveMOvie(Movie movie);
	public ArrayList<Movie> listAllMovie();
	public Movie listMovieById(int id);
}

package movie;
public class Movie {
 private int id;
 private int price;
 private String time;
 private String name;
 private String cinema;
 private String seat;
 private String l1;
 private String l2;
 private String l3;
 private String l4;
 private String l5;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCinema() {
	return cinema;
}
public void setCinema(String cinema) {
	this.cinema = cinema;
}
public String getSeat() {
	return seat;
}
public void setSeat(String seat) {
	this.seat = seat;
}
public String getL1() {
	return l1;
}
public void setL1(String l1) {
	this.l1 = l1;
}
public String getL2() {
	return l2;
}
public void setL2(String l2) {
	this.l2 = l2;
}
public String getL3() {
	return l3;
}
public void setL3(String l3) {
	this.l3 = l3;
}
public String getL4() {
	return l4;
}
public void setL4(String l4) {
	this.l4 = l4;
}
public String getL5() {
	return l5;
}
public void setL5(String l5) {
	this.l5 = l5;
}
}

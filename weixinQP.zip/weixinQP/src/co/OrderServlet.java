package co;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.io.IOException;
import java.util.Arrays;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.SimpleAttributeSet;

import movie.Order;

import dao.MovieDAOImpl;


public class OrderServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<String> list = Arrays.asList(request.getParameter("seat").split(","));
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int row=0,col=0;
		try{
			connection = new MovieDAOImpl().getConnection();
			for(int i=0;i<list.size();i++){
				int seatId = (Integer.parseInt(request.getParameter("id"))-1)*5+ Integer.parseInt(new String(new char[]{list.get(i).charAt(0)}));
				String sql = "update movie_seat set l" +
					list.get(i).charAt(1) + "=2 " +
					"where id=" +
					seatId;		
				System.out.println(sql);
				row=list.get(i).charAt(1);
				col=list.get(i).charAt(0);
				stmt = connection.prepareStatement(sql);
				stmt.execute();
			}
			
			stmt = connection.prepareStatement("select * from movie_information where id="+request.getParameter("id"));
		    rs = stmt.executeQuery();
			if(rs.next()){		
				stmt = connection.prepareStatement("insert into movie_order values(" + 
						rs.getInt(5)+",'" +
						rs.getString(1) + "','" + 
						rs.getString(2)+ "'," + "'" + request.getParameter("seat") + "',"+
						rs.getInt(4)+",'" +
						new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + "','" + 
						rs.getString(6) + "',"+
						Integer.parseInt(request.getParameter("count")) + ")" );
			    stmt.execute();
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(connection!=null){
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	
		response.sendRedirect("order.jsp");
		//request.getRequestDispatcher("order.jsp").forward(request, response);
	}
	
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    	doGet(request, response);
    }
}

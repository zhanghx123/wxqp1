package co;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.org.apache.regexp.internal.REUtil;


import dao.MovieDAOImpl;

public class SeatServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Connection connection = null; 
		int id = (Integer.parseInt(request.getParameter("id"))-1)*5;
		String sql = "select * from movie_seat where id>" + id + " limit 5";
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			//System.out.println(sql);
			connection = new MovieDAOImpl().getConnection();;
			stmt = connection.prepareStatement(sql);
			rs = stmt.executeQuery();
			request.setAttribute("seat",rs);
			/*(while(rs.next()){
				System.out.println(rs.getString(1)+ " " + rs.getString(2)+ " " + rs.getString(3)+ " " + rs.getString(4)+ " " + rs.getString(5));
			}*/
			request.getRequestDispatcher("demo.jsp").forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(connection!=null){
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request,response);
	}


}
